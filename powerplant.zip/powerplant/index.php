<?php
require 'connection.php';
session_start();

if(isset($_SESSION["login"])) {
    header("location: admin/logout.php");
}

if(isset($_POST["regist"])) {
    $name = htmlspecialchars($_POST["name"]);
    $password = htmlspecialchars($_POST["pass"]);
    $code1 = htmlspecialchars($_POST["code1"]);
    $code2 = htmlspecialchars($_POST["code2"]);
    $code3 = htmlspecialchars($_POST["code3"]);
    $code4 = htmlspecialchars($_POST["code4"]);

    $password = password_hash($password, PASSWORD_DEFAULT);
    $code = $code1 . $code2 . $code3 . $code4;
    $code = (int)$code;

    mysqli_query($conn, "INSERT INTO controller VALUES ('', '$name', '$password', '$code')");
    if(mysqli_affected_rows($conn) > 0) {
        header("location: login.php");
    }
};
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Nuclear Controller Regist</title>
</head>
<body>
    <form class="login-page for-layer" action="" method="POST">
        <div class="for-card">
            <div class="for-btn-shaped-box">
                <img class="btn-bgr" src="assets/footer-bgr.png">
                <h5>Controller Regist</h5>
            </div>
            <div class="for-btn-shaped-box">
                <img class="btn-bgr" src="assets/data-bgr.png">
                <div class="btn-logo">
                    <img class="btn-icon" style="filter:brightness(1.5)" src="assets/for-username.png">
                </div>
                <div class="prompt">
                    <label for="name">Username</label>
                    <input id="name" name="name" type="text" placeholder="Controller name" autocomplete="off" required>
                </div>
            </div>
            <div class="for-btn-shaped-box">
                <img class="btn-bgr" src="assets/data-bgr.png">
                <div class="btn-logo">
                    <img class="btn-icon" src="assets/password.png">
                </div>
                <div class="prompt">
                    <label for="pass">Password</label>
                    <input id="pass" name="pass" type="password" placeholder="Controller password" autocomplete="off" required>
                </div>
            </div>
            <div class="for-btn-shaped-box">
                <img class="btn-bgr" src="assets/data-bgr.png">
                <div class="btn-logo">
                    <img class="btn-icon" src="assets/nuclear.png">
                </div>
                <div class="prompt">
                    <label for="code1">Nuclear Code</label>
                    <div class="sub-prompt">
                        <input id="code1" class="nuke-code" name="code1" type="text" maxlength="1" placeholder="0" autocomplete="off" required>
                        <input id="code2" class="nuke-code" name="code2" type="text" maxlength="1" placeholder="0" autocomplete="off" required>
                        <input id="code3" class="nuke-code" name="code3" type="text" maxlength="1" placeholder="0" autocomplete="off" required>
                        <input id="code4" class="nuke-code" name="code4" type="text" maxlength="1" placeholder="0" autocomplete="off" required>
                    </div>
                </div>
            </div>
            <a type="submit" name="login" href="login.php" class="for-btn-shaped-box regist-btn" style="text-decoration:none;color:rgb(40, 40, 40);">
                <img class="btn-bgr" src="assets/footer-bgr.png">
                <h5>Login</h5>
            </a>
            <button type="submit" name="regist" class="for-btn-shaped-box regist-btn">
                <img class="btn-bgr" src="assets/footer-bgr.png">
                <h5>Regist</h5>
            </button>
        </div>
    </form>
    <section class="device-to-small">
        <img src="assets/device.png">
        <h5>System supported on Desktop only</h5>
    </section>
    <script>
        const page = document.querySelector('.login-page');
        let pWidth = screen.availWidth;
        if(pWidth < 1200) {
            page.remove();
        };

        const codeField = document.querySelectorAll('.nuke-code');
        codeField.forEach(e=> {
            e.addEventListener(
                'keyup', function() {
                    let capVal = e.value;
                    let isNum = /^\d+$/.test(capVal);
                    if(isNum == false) {
                        e.value = '';
                    };
                }
            );
        });
    </script>
</body>
</html>