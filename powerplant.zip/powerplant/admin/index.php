<?php
require '../connection.php';
session_start();

if(isset($_SESSION["login"])) {
    $kode = $_GET["code"];
    $datas = mysqli_query($conn, "SELECT * FROM nuclear WHERE kode = '$kode'");
    $thermal = mysqli_num_rows(mysqli_query($conn, "SELECT type FROM nuclear WHERE type = 'thermal' AND kode = '$kode'"));
    $nuclear = mysqli_num_rows(mysqli_query($conn, "SELECT type FROM nuclear WHERE type = 'nuclear' AND kode = '$kode'"));
    $bio = mysqli_num_rows(mysqli_query($conn, "SELECT type FROM nuclear WHERE type = 'bio' AND kode = '$kode'"));
    $getProfile = mysqli_query($conn, "SELECT * FROM controller WHERE kode = '$kode'");
    $byData = mysqli_fetch_assoc($getProfile);

    if(isset($_POST["add"])) {
        $name = htmlspecialchars($_POST["pwrName"]);
        $type = htmlspecialchars($_POST["type"]);
        $capacity = htmlspecialchars($_POST["pwrCap"]);
        $capacity = (int)$capacity;

        mysqli_query($conn, "INSERT INTO nuclear VALUES ('', '$name', '$type', '$capacity', '$kode')");
        if(mysqli_affected_rows($conn) > 0) {
            $created = true;
        };
    };
} else {
    header("location: ../login.php");
};
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
    <title>Power Plant Data - Admin</title>
</head>
<body>
    <section class="page">
        <img src="../assets/city-bgr.png" class="main-bgr">
        <header>
            <div class="card">
                <img src="../assets/data-bgr.png">
                <p>Thermo Nuclear</p>
                <h5><span><?= $thermal;?></span> Unit</h5>
            </div>
            <div class="card">
                <img src="../assets/data-bgr.png">
                <p>Conventional Nuclear</p>
                <h5><span><?= $nuclear;?></span> Unit</h5>
            </div>
            <div class="card">
                <img src="../assets/data-bgr.png">
                <p>Bio Nuclear</p>
                <h5><span><?= $bio;?></span> Unit</h5>
            </div>
        </header>
        <div class="data-container">
            <div class="output-area">
                <div class="crane-box">
                    <img src="../assets/crane.png">
                </div>
                <?php foreach($datas as $data):?>
                    <div class="power-box <?= $data["type"];?>">
                        <div class="power-image">

                        </div>
                        <div class="power-desc">
                            <?= $data["name"];?>
                        </div>
                    </div>
                <?php endforeach;?>
            </div>
        </div>
        <footer>
            <form class="profile-btn" action="" method="POST">
                <div class="profile">
                    <img class="profile-bgr" src="../assets/footer-bgr.png">
                    <div class="profile-btn-logo">
                        <img src="../assets/for-username.png">
                    </div>
                    <div class="profile-btn-open">
                        Controller Profile
                    </div>
                </div>
            </form>
            <form class="data-adder" action="" method="POST">
                <img src="../assets/footer-bgr.png">
                <div class="form-title">
                    <h5>Add Nuclear Manufacture</h5>
                </div>
                <div class="form-input">
                    <div class="prompt">
                        <label for="name">Company</label>
                        <input id="name" name="pwrName" type="text" placeholder="Add nuclear company" autocomplete="off" maxlength="10" required>
                    </div>
                    <div class="prompt">
                        <label for="cap">Max Capacity</label>
                        <input id="cap" name="pwrCap" type="text" placeholder="Max missile can stored" autocomplete="off" maxlength="5" required>
                    </div>
                    <div class="prompt">
                        <label for="type">Nuclear Type</label>
                        <input id="type" name="typeName" type="text" placeholder="Select nuclear type" readonly required>
                        <input id="typeVal" name="type" type="hidden" readonly required>
                    </div>
                </div>
                <div class="form-submit">
                    <button name="add" type="submit">Add Manufacture</button>
                </div>
            </form>
        </footer>
        <div class="type-layer for-layer hide">
            <div class="for-card">
                <div class="for-btn-shaped-box">
                    <img class="btn-bgr" src="../assets/footer-bgr.png">
                    <h5>Select Nuclear Type</h5>
                </div>
                <div class="for-btn-shaped-box option">
                    <img class="btn-bgr" src="../assets/data-bgr.png">
                    <div class="btn-logo">
                        <img class="btn-icon" style="--hue:300deg" src="../assets/nuclear.png">
                    </div>
                    <div id="thermal" name="Thermo Nuclear" class="type-opt">
                        Thermo Nuclear
                    </div>
                </div>
                <div class="for-btn-shaped-box option">
                    <img class="btn-bgr" src="../assets/data-bgr.png">
                    <div class="btn-logo">
                        <img class="btn-icon" src="../assets/nuclear.png">
                    </div>
                    <div id="nuclear" name="Conventional Nuclear" class="type-opt">
                        Conventional Nuclear
                    </div>
                </div>
                <div class="for-btn-shaped-box option">
                    <img class="btn-bgr" src="../assets/data-bgr.png">
                    <div class="btn-logo">
                        <img class="btn-icon" style="--hue:-300deg" src="../assets/nuclear.png">
                    </div>
                    <div id="bio" name="Bio Nuclear" class="type-opt">
                        Bio Nuclear
                    </div>
                </div>
                <div class="for-btn-shaped-box back" style="padding: 24px 48px;">
                    <img class="btn-bgr" src="../assets/footer-bgr.png">
                    <h5>Back</h5>
                </div>
            </div>
        </div>
        <div class="profile-layer for-layer hide">
            <div class="for-card">
                <div class="for-btn-shaped-box">
                    <img class="btn-bgr" src="../assets/footer-bgr.png">
                    <h5>Controller Profile</h5>
                </div>
                <div class="for-btn-shaped-box">
                    <img class="btn-bgr" src="../assets/data-bgr.png">
                    <div class="btn-logo">
                        <img class="btn-icon" src="../assets/for-username.png">
                    </div>
                    <div class="profile-data">
                        <span class="title-holder">Username</span>
                        <?= $byData["name"];?>
                    </div>
                </div>
                <div class="for-btn-shaped-box">
                    <img class="btn-bgr" src="../assets/data-bgr.png">
                    <div class="btn-logo">
                        <img class="btn-icon" src="../assets/nuclear.png">
                    </div>
                    <div class="profile-data">
                        <span class="title-holder">Nuke Code</span>
                        <input id="revealed-nuke-code" type="text" value="<?= $byData["kode"];?>" readonly hidden>
                        <div class="code-comb">
                            <span class="reveal-code"></span>
                            <span class="reveal-code"></span>
                            <span class="reveal-code"></span>
                            <span class="reveal-code"></span>
                        </div>
                    </div>
                </div>
                <a href="deleteAcc.php?code=<?= $kode;?>" class="for-btn-shaped-box for-btn" style="padding: 24px 48px;">
                    <img class="btn-bgr" src="../assets/footer-bgr.png">
                    <h5>Delete</h5>
                </a>
                <a href="logout.php" class="for-btn-shaped-box for-btn" style="padding: 24px 48px;">
                    <img class="btn-bgr" src="../assets/footer-bgr.png">
                    <h5>Log Out</h5>
                </a>
                <div class="for-btn-shaped-box back" style="padding: 24px 48px;">
                    <img class="btn-bgr" src="../assets/footer-bgr.png">
                    <h5>Back</h5>
                </div>
            </div>
        </div>
        <div class="nuclear-empty">
            <div class="empty-title">
                Nuclear
                <br>
                Empty...
            </div>
        </div>
    </section>
    <section class="device-to-small">
        <img src="../assets/device.png">
        <h5>System supported on Desktop only</h5>
    </section>
    <script>
        const page = document.querySelector('.page');
        let pWidth = screen.availWidth;
        if(pWidth < 1200) {
            page.remove();
        };

        const powerArea = document.querySelector('.output-area');
        const powerInfo = document.querySelectorAll('.power-box');
        const crane = document.querySelector('.crane-box');
        const empty = document.querySelector('.nuclear-empty');
        const capacity = document.getElementById('cap');
        capacity.addEventListener(
            'keyup', function() {
                let capVal = capacity.value;
                let isNum = /^\d+$/.test(capVal);
                if(isNum == false) {
                    capacity.value = '';
                };
            }
        );
        function moveAndBuild() {
            function backPos() {
                crane.style.transition = '5s';
                crane.style.left = '-100px';
            }
            setTimeout(backPos, 9000);

            function side() {
                crane.style.transition = '0s';
                crane.style.transform = 'rotateY(180deg)';
            }
            setTimeout(side, 8500);

            function build() {
                const box = document.createElement('div');
                box.classList.add('power-box');
                const logo = document.createElement('div');
                logo.classList.add('power-image');
                const desc = document.createElement('div');
                desc.classList.add('power-desc');
                logo.innerHTML = `
                    <img src="../assets/building.png">
                `;
                desc.innerHTML = 'Building...';
                box.appendChild(logo);
                box.appendChild(desc);
                powerArea.appendChild(box);

                crane.style.transition = '0s';
                crane.style.bottom = '0';
            }
            setTimeout(build, 5500);

            function update() {
                window.location = 'index.php?code=<?= $kode;?>';
            }

            setTimeout(update, 15000);
        }
        if(powerInfo.length > 0) {
            powerArea.parentElement.scrollTop = powerArea.parentElement.scrollHeight;
            empty.style.transition = '0s';
            empty.style.transform = 'scale(0)';
            for(let i = 0; i < powerInfo.length; i++) {
                powerInfo[i].querySelector('.power-image').innerHTML = `
                    <img src="../assets/nuclear.png">
                `;
                if(powerInfo[i].classList.contains('thermal')) {
                    powerInfo[i].style.filter = 'hue-rotate(300deg)';
                } else if(powerInfo[i].classList.contains('bio')) {
                    powerInfo[i].style.filter = 'hue-rotate(-300deg)';
                }
            }
            <?php if(isset($created)):?>
                let posX = powerInfo[powerInfo.length - 1].offsetLeft + powerInfo[powerInfo.length - 1].offsetWidth;

                if(powerInfo.length % 10 == 0) {
                    let posX2 = powerInfo[powerInfo.length - 10].offsetLeft + powerInfo[powerInfo.length - 10].offsetWidth / 2 ;
                    crane.style.bottom = '-50px';
                    crane.style.left = posX2 - 25 + 'px';
                } else {
                    crane.style.bottom = '0';
                    crane.style.left = posX + 25 + 'px';
                }

                moveAndBuild();
            <?php endif;?>
        } else {
            crane.style.transition = '0s';
            crane.style.visibility = 'hidden';
            crane.style.bottom = '-50px';
            <?php if(isset($created)):?>
                empty.style.transform = 'scale(0)';
                crane.style.visibility = 'visible';
                crane.style.left = '25px';

                moveAndBuild();
            <?php endif;?>
        };

        const typeLayer = document.querySelector('.type-layer');
        const inputType = document.getElementById('type');
        const backBtn = document.querySelectorAll('.back');
        const typeOpt = document.querySelectorAll('.option');
        const profileBtn = document.querySelector('.profile-btn');
        const profileData = document.querySelector('.profile-layer');
        const profileCode = document.getElementById('revealed-nuke-code').value;
        const codeCombination = document.querySelectorAll('.reveal-code');
        backBtn.forEach(e=> {
            e.addEventListener(
                'click', function() {
                    e.parentElement.parentElement.classList.add('hide');
                }
            )
        });
        inputType.addEventListener(
            'click', function() {
                typeLayer.classList.remove('hide');
            }
        );
        typeOpt.forEach(e => {
            e.addEventListener(
                'click', function() {
                    const selectedVal = e.querySelector('.type-opt');
                    const typeVal = document.getElementById('typeVal');

                    inputType.value = selectedVal.getAttribute('name');
                    typeVal.value = selectedVal.id;
                    typeLayer.classList.add('hide');
                }
            )
        });
        profileBtn.addEventListener(
            'click', function() {
                profileData.classList.remove('hide');
            }
        )            
        for(let i = 0; i < codeCombination.length; i++) {
            codeCombination[i].textContent = profileCode[i];
        };    
    </script>
</body>
</html>