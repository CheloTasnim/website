<?php
require '../connection.php';
session_start();

if(isset($_SESSION["login"])) {
    session_destroy();
    $kode = $_GET["code"];
    mysqli_query($conn, "DELETE FROM controller WHERE kode = '$kode'");
    mysqli_query($conn, "DELETE FROM nuclear WHERE kode = '$kode'");
    header("location: ../login.php");   
} else {
    header("location: ../login.php");
}
?>