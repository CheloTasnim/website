<?php
require 'connection.php';
session_start();

if(isset($_SESSION["login"])) {
    header("location: admin/logout.php");
}

if(isset($_POST["login"])) {
    $name = htmlspecialchars($_POST["name"]);
    $password = htmlspecialchars($_POST["pass"]);
    $data = mysqli_query($conn, "SELECT * FROM controller WHERE name = '$name'");
    if(mysqli_num_rows($data) === 1) {
        $byField = mysqli_fetch_assoc($data);
        if(password_verify($password, $byField["password"])) {
            $nukeCode = $byField["kode"];
            $_SESSION["login"] = true;
            header("location: admin/index.php?code=$nukeCode");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Nuclear Controller Login</title>
</head>
<body>
    <form class="login-page for-layer" action="" method="POST">
        <div class="for-card">
            <div class="for-btn-shaped-box">
                <img class="btn-bgr" src="assets/footer-bgr.png">
                <h5>Controller Login</h5>
            </div>
            <div class="for-btn-shaped-box">
                <img class="btn-bgr" src="assets/data-bgr.png">
                <div class="btn-logo">
                    <img class="btn-icon" style="filter:brightness(1.5)" src="assets/for-username.png">
                </div>
                <div class="prompt">
                    <label for="name">Username</label>
                    <input id="name" name="name" type="text" placeholder="Controller name" autocomplete="off" required>
                </div>
            </div>
            <div class="for-btn-shaped-box">
                <img class="btn-bgr" src="assets/data-bgr.png">
                <div class="btn-logo">
                    <img class="btn-icon" src="assets/password.png">
                </div>
                <div class="prompt">
                    <label for="pass">Password</label>
                    <input id="pass" name="pass" type="password" placeholder="Controller password" autocomplete="off" required>
                </div>
            </div>
            <button type="submit" name="login" class="for-btn-shaped-box regist-btn">
                <img class="btn-bgr" src="assets/footer-bgr.png">
                <h5>Login</h5>
            </button>
            <a type="submit" name="regist" href="index.php" class="for-btn-shaped-box regist-btn" style="text-decoration:none;color:rgb(40, 40, 40);">
                <img class="btn-bgr" src="assets/footer-bgr.png">
                <h5>Regist</h5>
            </a>
        </div>
    </form>
    <section class="device-to-small">
        <img src="assets/device.png">
        <h5>System supported on Desktop only</h5>
    </section>
    <script>
        const page = document.querySelector('.login-page');
        let pWidth = screen.availWidth;
        if(pWidth < 1200) {
            page.remove();
        }
    </script>
</body>
</html>